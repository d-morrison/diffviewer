#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom utils str
## usethis namespace: end
NULL
